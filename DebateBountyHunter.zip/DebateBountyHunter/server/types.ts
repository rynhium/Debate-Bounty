import { User, Clan, Bounty, InsertUser } from "@shared/schema";
import { Store } from "express-session";

export interface IStorage {
  sessionStore: Store;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;

  // Bounty operations
  getBounty(id: number): Promise<Bounty | undefined>;
  createBounty(bounty: Omit<Bounty, "id">): Promise<Bounty>;
  updateBounty(id: number, updates: Partial<Bounty>): Promise<Bounty>;
  listBounties(filter?: Partial<Bounty>): Promise<Bounty[]>;

  // Clan operations
  getClan(id: number): Promise<Clan | undefined>;
  createClan(clan: Omit<Clan, "id">): Promise<Clan>;
  updateClan(id: number, updates: Partial<Clan>): Promise<Clan>;
}
