import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { bountyTierSchema, insertBountySchema, insertClanSchema } from "@shared/schema";
import { z } from "zod";
import Stripe from "stripe";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("Missing required Stripe secret: STRIPE_SECRET_KEY");
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16"
});

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Clan routes
  app.post("/api/clans", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const validation = insertClanSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json(validation.error);
    }

    // Create the clan
    const clan = await storage.createClan({
      ...validation.data,
      reputationScore: 0
    });

    // Update the user's clan ID
    await storage.updateUser(req.user.id, {
      clanId: clan.id
    });

    res.status(201).json(clan);
  });

  app.get("/api/clans/:id", async (req, res) => {
    const clan = await storage.getClan(parseInt(req.params.id));
    if (!clan) {
      return res.status(404).json({ message: "Clan not found" });
    }
    res.json(clan);
  });

  // Stripe payment route
  app.post("/api/create-payment-intent", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const { amount } = req.body;
      const paymentIntent = await stripe.paymentIntents.create({
        amount,
        currency: "usd",
        automatic_payment_methods: {
          enabled: true,
        },
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Bounty routes
  app.post("/api/bounties", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const validation = insertBountySchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json(validation.error);
    }

    const bounty = await storage.createBounty({
      ...validation.data,
      createdById: req.user.id,
      status: "open",
      createdAt: new Date(),
      claimedById: null,
      fileUrl: null,
      paymentIntentId: req.body.paymentIntentId
    });

    res.status(201).json(bounty);
  });

  app.get("/api/bounties", async (req, res) => {
    const tier = req.query.tier as string;
    if (tier && !bountyTierSchema.safeParse(tier).success) {
      return res.status(400).json({ message: "Invalid tier" });
    }

    const bounties = await storage.listBounties(
      tier ? { tier } : undefined
    );
    res.json(bounties);
  });

  app.post("/api/bounties/:id/claim", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const bountyId = parseInt(req.params.id);
    const bounty = await storage.getBounty(bountyId);

    if (!bounty) {
      return res.status(404).json({ message: "Bounty not found" });
    }

    if (bounty.status !== "open") {
      return res.status(400).json({ message: "Bounty is not available" });
    }

    if (bounty.tier === "A" && req.user.hunterLevel < 4) {
      return res.status(403).json({ message: "Hunter level too low for tier A" });
    }

    const updatedBounty = await storage.updateBounty(bountyId, {
      status: "claimed",
      claimedById: req.user.id
    });

    res.json(updatedBounty);
  });

  app.post("/api/bounties/:id/complete", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const bountyId = parseInt(req.params.id);
    const bounty = await storage.getBounty(bountyId);

    if (!bounty) {
      return res.status(404).json({ message: "Bounty not found" });
    }

    if (bounty.claimedById !== req.user.id) {
      return res.status(403).json({ message: "Not your bounty" });
    }

    const updatedBounty = await storage.updateBounty(bountyId, {
      status: "completed"
    });

    // Update hunter's reputation
    const reputationGain = {
      A: 40,
      B: 30,
      C: 20,
      D: 10
    }[bounty.tier] || 0;

    await storage.updateUser(req.user.id, {
      reputation: req.user.reputation + reputationGain
    });

    res.json(updatedBounty);
  });

  const httpServer = createServer(app);
  return httpServer;
}