import { drizzle } from "drizzle-orm/neon-http";
import { neon, neonConfig } from "@neondatabase/serverless";
import { IStorage } from "./types";
import { User, Clan, Bounty, InsertUser, users, clans, bounties } from "@shared/schema";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { eq } from "drizzle-orm";

const PostgresSessionStore = connectPg(session);

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL environment variable is required");
}

// Configure neon to use fetch
neonConfig.fetchConnectionCache = true;
const sql = neon(process.env.DATABASE_URL);
const db = drizzle(sql);

export class DatabaseStorage implements IStorage {
  public sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      conObject: {
        connectionString: process.env.DATABASE_URL,
      },
      createTableIfMissing: true,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values({
      ...insertUser,
      hunterLevel: 1,
      reputation: 0,
      clanId: null,
    }).returning();
    return result[0];
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const result = await db.update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async getBounty(id: number): Promise<Bounty | undefined> {
    const result = await db.select().from(bounties).where(eq(bounties.id, id));
    return result[0];
  }

  async createBounty(bounty: Omit<Bounty, "id">): Promise<Bounty> {
    const result = await db.insert(bounties).values(bounty).returning();
    return result[0];
  }

  async updateBounty(id: number, updates: Partial<Bounty>): Promise<Bounty> {
    const result = await db.update(bounties)
      .set(updates)
      .where(eq(bounties.id, id))
      .returning();
    return result[0];
  }

  async listBounties(filter?: Partial<Bounty>): Promise<Bounty[]> {
    let query = db.select().from(bounties);
    if (filter) {
      Object.entries(filter).forEach(([key, value]) => {
        if (value !== undefined) {
          query = query.where(eq(bounties[key as keyof typeof bounties], value));
        }
      });
    }
    return await query;
  }

  async getClan(id: number): Promise<Clan | undefined> {
    const result = await db.select().from(clans).where(eq(clans.id, id));
    return result[0];
  }

  async createClan(clan: Omit<Clan, "id">): Promise<Clan> {
    const result = await db.insert(clans).values(clan).returning();
    return result[0];
  }

  async updateClan(id: number, updates: Partial<Clan>): Promise<Clan> {
    const result = await db.update(clans)
      .set(updates)
      .where(eq(clans.id, id))
      .returning();
    return result[0];
  }
}

export const storage = new DatabaseStorage();