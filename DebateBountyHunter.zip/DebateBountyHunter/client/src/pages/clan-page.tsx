import { useQuery } from "@tanstack/react-query";
import { Clan } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Trophy, Users, Star, Plus } from "lucide-react";
import { Dialog, DialogTrigger } from "@/components/ui/dialog";
import CreateClanForm from "@/components/create-clan-form";

export default function ClanPage() {
  const { user } = useAuth();

  const { data: clan, isLoading } = useQuery<Clan>({
    queryKey: ["/api/clans", user?.clanId],
    enabled: !!user?.clanId,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#36393f]">
        <div className="animate-spin h-8 w-8 border-4 border-[#5865f2] border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!clan) {
    return (
      <div className="min-h-screen bg-[#36393f] text-white">
        <div className="container mx-auto py-16 px-4">
          <div className="max-w-md mx-auto text-center space-y-6">
            <h1 className="text-4xl font-bold tracking-tighter text-white">
              Join a Clan
            </h1>
            <p className="text-gray-400">
              Create or join a clan to participate in competitions and earn rewards with your school
            </p>
            <Dialog>
              <DialogTrigger asChild>
                <Button className="bg-[#5865f2] hover:bg-[#4752c4] text-white">
                  <Plus className="mr-2 h-4 w-4" />
                  Create New Clan
                </Button>
              </DialogTrigger>
              <CreateClanForm />
            </Dialog>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#36393f] text-white">
      <div className="container mx-auto py-8 px-4">
        <div className="grid gap-8">
          <div className="space-y-2">
            <h1 className="text-4xl font-bold tracking-tighter text-white">
              {clan.name}
            </h1>
            <p className="text-gray-400">{clan.description}</p>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <Card className="bg-[#2f3136] border-none transform transition-all hover:translate-y-[-2px]">
              <CardHeader className="flex flex-row items-center space-x-4">
                <Trophy className="w-8 h-8 text-[#5865f2]" />
                <CardTitle className="text-white">Clan Reputation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-[#5865f2]">
                  {clan.reputationScore}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#2f3136] border-none transform transition-all hover:translate-y-[-2px]">
              <CardHeader className="flex flex-row items-center space-x-4">
                <Users className="w-8 h-8 text-[#5865f2]" />
                <CardTitle className="text-white">Members</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-[#5865f2]">12</div>
              </CardContent>
            </Card>

            <Card className="bg-[#2f3136] border-none transform transition-all hover:translate-y-[-2px]">
              <CardHeader className="flex flex-row items-center space-x-4">
                <Star className="w-8 h-8 text-[#5865f2]" />
                <CardTitle className="text-white">Competitions Won</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-[#5865f2]">3</div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-[#2f3136] border-none">
            <CardHeader>
              <CardTitle className="text-white">Active Competitions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-[#40444b]">
                  <div className="font-medium text-white">2AC Block Building Challenge</div>
                  <div className="text-sm text-gray-400 mt-1">
                    Build the best 2AC block against the Politics DA
                  </div>
                  <div className="mt-4">
                    <Button className="bg-[#5865f2] hover:bg-[#4752c4] text-white">
                      Join Competition
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}