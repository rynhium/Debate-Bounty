import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Bounty, BountyTier } from "@shared/schema";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import BountyCard from "@/components/bounty-card";
import CreateBountyForm from "@/components/create-bounty-form";
import { Plus } from "lucide-react";

export default function BountyBoard() {
  const [selectedTier, setSelectedTier] = useState<BountyTier | "all">("all");
  
  const { data: bounties = [], isLoading } = useQuery<Bounty[]>({
    queryKey: ["/api/bounties", selectedTier !== "all" ? selectedTier : undefined],
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8 px-4">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold tracking-tighter">Bounty Board</h1>
            <p className="text-muted-foreground">
              Find and claim bounties to earn rewards
            </p>
          </div>

          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create Bounty
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <CreateBountyForm />
            </DialogContent>
          </Dialog>
        </div>

        <Tabs
          value={selectedTier}
          onValueChange={(value) => setSelectedTier(value as BountyTier | "all")}
          className="mb-8"
        >
          <TabsList>
            <TabsTrigger value="all">All Tiers</TabsTrigger>
            <TabsTrigger value="A">Tier A</TabsTrigger>
            <TabsTrigger value="B">Tier B</TabsTrigger>
            <TabsTrigger value="C">Tier C</TabsTrigger>
            <TabsTrigger value="D">Tier D</TabsTrigger>
          </TabsList>
        </Tabs>

        {isLoading ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="h-[200px] rounded-lg bg-muted animate-pulse"
              />
            ))}
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {bounties.map((bounty) => (
              <BountyCard key={bounty.id} bounty={bounty} />
            ))}
            {bounties.length === 0 && (
              <div className="col-span-full text-center py-8 text-muted-foreground">
                No bounties found
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
