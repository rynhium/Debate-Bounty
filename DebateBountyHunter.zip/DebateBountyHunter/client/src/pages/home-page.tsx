import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sword, Users, Trophy, Star } from "lucide-react";

export default function HomePage() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 animate-gradient-x">
      <div className="absolute inset-0 bg-grid-black/[0.02] -z-10" />
      <div className="container mx-auto py-8 px-4">
        <div className="grid gap-6">
          <div className="space-y-2">
            <h1 className="text-4xl font-bold tracking-tighter bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent animate-text">
              Welcome, {user?.username}!
            </h1>
            <p className="text-muted-foreground">
              Level {user?.hunterLevel} Hunter | {user?.reputation} Reputation
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="transform transition-all hover:scale-105">
              <CardHeader className="flex flex-row items-center space-x-4">
                <Sword className="w-8 h-8 text-primary" />
                <CardTitle>Active Bounties</CardTitle>
              </CardHeader>
              <CardContent>
                <Link href="/bounties">
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                    View Bounties
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="transform transition-all hover:scale-105">
              <CardHeader className="flex flex-row items-center space-x-4">
                <Users className="w-8 h-8 text-primary" />
                <CardTitle>Your Clan</CardTitle>
              </CardHeader>
              <CardContent>
                <Link href="/clans">
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                    View Clan
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="transform transition-all hover:scale-105">
              <CardHeader className="flex flex-row items-center space-x-4">
                <Trophy className="w-8 h-8 text-primary" />
                <CardTitle>Competitions</CardTitle>
              </CardHeader>
              <CardContent>
                <Link href="/clans">
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                    View Competitions
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="transform transition-all hover:scale-105">
              <CardHeader className="flex flex-row items-center space-x-4">
                <Star className="w-8 h-8 text-primary" />
                <CardTitle>Profile</CardTitle>
              </CardHeader>
              <CardContent>
                <Link href="/profile">
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                    View Profile
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="backdrop-blur-sm bg-white/50">
              <CardHeader>
                <CardTitle>Hunter Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="text-sm font-medium">Level {user?.hunterLevel}</div>
                    <div className="h-2 bg-muted rounded-full mt-2">
                      <div 
                        className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full transition-all duration-500" 
                        style={{ width: `${(user?.reputation || 0) % 100}%` }}
                      />
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {100 - ((user?.reputation || 0) % 100)} reputation points until next level
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="backdrop-blur-sm bg-white/50">
              <CardHeader>
                <CardTitle>Latest Achievements</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[200px]">
                  <div className="space-y-4">
                    {[
                      "Completed first bounty",
                      "Joined a clan",
                      "Reached Level 2",
                      "Earned 50 reputation"
                    ].map((achievement, i) => (
                      <div key={i} className="flex items-center gap-2 group">
                        <div className="h-2 w-2 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full transform transition-all group-hover:scale-125" />
                        <span className="group-hover:text-blue-600 transition-colors">{achievement}</span>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}