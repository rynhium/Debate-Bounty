import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertClanSchema } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DialogHeader, DialogTitle, DialogContent } from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { z } from "zod";

type FormData = z.infer<typeof insertClanSchema>;

export default function CreateClanForm() {
  const { toast } = useToast();
  const { user } = useAuth();

  const form = useForm<FormData>({
    resolver: zodResolver(insertClanSchema),
    defaultValues: {
      name: "",
      description: "",
    },
  });

  const createClanMutation = useMutation({
    mutationFn: async (data: FormData) => {
      try {
        const res = await apiRequest("POST", "/api/clans", data);
        if (!res.ok) {
          const error = await res.json();
          throw new Error(error.message || "Failed to create clan");
        }
        return await res.json();
      } catch (error: any) {
        console.error("Clan creation error:", error);
        if (error.message.includes("duplicate key")) {
          throw new Error("A clan with this name already exists");
        }
        throw new Error(error.message || "Failed to create clan");
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clans", user?.clanId] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Success!",
        description: "Your clan has been created successfully.",
      });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: FormData) => {
    try {
      await createClanMutation.mutateAsync(data);
    } catch (error) {
      // Error is handled by mutation's onError
    }
  };

  return (
    <DialogContent className="sm:max-w-[425px] bg-[#2f3136] text-white">
      <DialogHeader>
        <DialogTitle className="text-2xl font-bold text-white">
          Create New Clan
        </DialogTitle>
      </DialogHeader>

      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="space-y-6"
        >
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-gray-200">Clan Name</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    className="bg-[#40444b] border-none text-white placeholder:text-gray-400"
                    placeholder="Enter clan name" 
                  />
                </FormControl>
                <FormMessage className="text-red-400" />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-gray-200">Description</FormLabel>
                <FormControl>
                  <Textarea 
                    {...field} 
                    className="bg-[#40444b] border-none text-white placeholder:text-gray-400 min-h-[100px]"
                    placeholder="Describe your clan"
                  />
                </FormControl>
                <FormMessage className="text-red-400" />
              </FormItem>
            )}
          />

          <Button
            type="submit"
            className="w-full bg-[#5865f2] hover:bg-[#4752c4] text-white"
            disabled={createClanMutation.isPending}
          >
            {createClanMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Creating...
              </>
            ) : (
              "Create Clan"
            )}
          </Button>
        </form>
      </Form>
    </DialogContent>
  );
}