import { useState } from "react";
import { Bounty } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface BountyCardProps {
  bounty: Bounty;
}

const tierColors = {
  A: "bg-red-100 text-red-800",
  B: "bg-orange-100 text-orange-800",
  C: "bg-yellow-100 text-yellow-800",
  D: "bg-green-100 text-green-800",
};

export default function BountyCard({ bounty }: BountyCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isExpanded, setIsExpanded] = useState(false);

  const claimMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/bounties/${bounty.id}/claim`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bounties"] });
      toast({
        title: "Bounty Claimed",
        description: "You have successfully claimed this bounty.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to claim bounty",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const completeMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/bounties/${bounty.id}/complete`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bounties"] });
      toast({
        title: "Bounty Completed",
        description: "Great job! Your reward will be processed soon.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to complete bounty",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between space-y-0">
        <CardTitle className="text-lg font-bold">{bounty.title}</CardTitle>
        <Badge className={tierColors[bounty.tier]}>Tier {bounty.tier}</Badge>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div
            className={`text-sm text-muted-foreground ${
              isExpanded ? "" : "line-clamp-2"
            }`}
          >
            {bounty.description}
          </div>
          {!isExpanded && (
            <Button
              variant="link"
              className="p-0 h-auto"
              onClick={() => setIsExpanded(true)}
            >
              Read more
            </Button>
          )}

          <div className="flex flex-col gap-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Reward</span>
              <span className="font-medium">${bounty.reward}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Deadline</span>
              <span className="font-medium">
                {bounty.deadline
                  ? format(new Date(bounty.deadline), "MMM d, yyyy")
                  : "No deadline"}
              </span>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            {bounty.status === "open" && (
              <Button
                onClick={() => claimMutation.mutate()}
                disabled={
                  claimMutation.isPending ||
                  (bounty.tier === "A" && (user?.hunterLevel || 0) < 4)
                }
              >
                Claim Bounty
              </Button>
            )}
            {bounty.status === "claimed" && bounty.claimedById === user?.id && (
              <Button
                onClick={() => completeMutation.mutate()}
                disabled={completeMutation.isPending}
              >
                Complete Bounty
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
