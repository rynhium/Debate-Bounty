import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { bountySchema, bountyCategories } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { useState, useEffect } from "react";

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

function BountyForm() {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();

  const form = useForm({
    resolver: zodResolver(bountySchema),
    defaultValues: {
      title: "",
      description: "",
      category: undefined,
      tier: "D",
      reward: 0,
      deadline: null,
    },
  });

  const createBountyMutation = useMutation({
    mutationFn: async (data: typeof form.getValues) => {
      if (!stripe || !elements) {
        throw new Error("Stripe not loaded");
      }

      // First create a payment intent
      const paymentRes = await apiRequest("POST", "/api/create-payment-intent", {
        amount: data.reward * 100 // Convert to cents
      });
      const { clientSecret } = await paymentRes.json();

      // Confirm the card payment
      const { error: stripeError } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: window.location.origin,
        },
      });

      if (stripeError) {
        throw new Error(stripeError.message);
      }

      // Create the bounty
      const bountyRes = await apiRequest("POST", "/api/bounties", {
        ...data,
        paymentIntentId: clientSecret.split("_secret_")[0]
      });
      return bountyRes.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bounties"] });
      toast({
        title: "Bounty Created",
        description: "Your bounty has been posted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create bounty",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <div className="space-y-4">
      <DialogHeader>
        <DialogTitle className="text-2xl font-bold">Create New Bounty</DialogTitle>
      </DialogHeader>

      <ScrollArea className="h-[60vh] px-4">
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit((data) => createBountyMutation.mutate(data))}
            className="space-y-4"
          >
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <ScrollArea className="h-[200px]">
                        {bountyCategories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </ScrollArea>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="tier"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tier</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select tier" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="A">Tier A ($20)</SelectItem>
                      <SelectItem value="B">Tier B ($15)</SelectItem>
                      <SelectItem value="C">Tier C ($10)</SelectItem>
                      <SelectItem value="D">Tier D ($5)</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="reward"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Reward ($)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-2">
              <FormLabel>Payment Information</FormLabel>
              <PaymentElement />
            </div>

            <div className="sticky bottom-0 pt-4 bg-background">
              <Button
                type="submit"
                className="w-full"
                disabled={createBountyMutation.isPending}
              >
                Create Bounty
              </Button>
            </div>
          </form>
        </Form>
      </ScrollArea>
    </div>
  );
}

export default function CreateBountyForm() {
  const [clientSecret, setClientSecret] = useState<string | null>(null);

  useEffect(() => {
    // Create initial PaymentIntent when form opens
    apiRequest("POST", "/api/create-payment-intent", { amount: 500 }) // Start with minimum amount (Tier D)
      .then((res) => res.json())
      .then((data) => setClientSecret(data.clientSecret))
      .catch((error) => console.error("Failed to load payment form:", error));
  }, []);

  if (!clientSecret) {
    return (
      <div className="p-4 text-center">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto" />
        <p className="mt-2 text-sm text-muted-foreground">Loading payment form...</p>
      </div>
    );
  }

  return (
    <Elements stripe={stripePromise} options={{ clientSecret }}>
      <BountyForm />
    </Elements>
  );
}