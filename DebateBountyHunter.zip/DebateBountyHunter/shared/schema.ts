import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  hunterLevel: integer("hunter_level").notNull().default(1),
  reputation: integer("reputation").notNull().default(0),
  tabRoomUsername: text("tabroom_username"),
  discordUsername: text("discord_username"),
  clanId: integer("clan_id"),
  avatarUrl: text("avatar_url")
});

export const clans = pgTable("clans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  reputationScore: integer("reputation_score").notNull().default(0)
});

export const bounties = pgTable("bounties", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // Added category field
  tier: text("tier").notNull(), // A, B, C, D
  reward: integer("reward").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  deadline: timestamp("deadline"),
  createdById: integer("created_by_id").notNull(),
  claimedById: integer("claimed_by_id"),
  status: text("status").notNull().default("open"), // open, claimed, completed
  fileUrl: text("file_url"),
  paymentIntentId: text("payment_intent_id") // Added for Stripe integration
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  tabRoomUsername: true,
  discordUsername: true,
  avatarUrl: true
});

export const insertClanSchema = createInsertSchema(clans);

export const insertBountySchema = createInsertSchema(bounties).pick({
  title: true,
  description: true,
  category: true,
  tier: true,
  reward: true,
  deadline: true
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Clan = typeof clans.$inferSelect;
export type Bounty = typeof bounties.$inferSelect;

export const bountyTierSchema = z.enum(["A", "B", "C", "D"]);
export type BountyTier = z.infer<typeof bountyTierSchema>;

export const bountyStatusSchema = z.enum(["open", "claimed", "completed"]);
export type BountyStatus = z.infer<typeof bountyStatusSchema>;

export const bountyCategories = [
  "Case Research",
  "Card Cutting",
  "2AC Block Building",
  "1NC Shell Construction",
  "Statistical Analysis",
  "Framework Research",
  "Theory Research",
  "Impact Research",
  "Other"
] as const;

export const bountySchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  category: z.enum(bountyCategories, {
    errorMap: () => ({ message: "Please select a category" }),
  }),
  tier: bountyTierSchema,
  reward: z.number().min(1, "Reward must be greater than 0"),
  deadline: z.date().optional().nullable(),
});